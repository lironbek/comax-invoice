import React from "react";

interface InvoiceReceiptProps {
  companyName?: string;
  branchName?: string;
  totalAmount?: string;
  items?: Array<{
    name: string;
    barcode: string;
    quantity: number;
    price: string;
  }>;
}

const InvoiceReceipt: React.FC<InvoiceReceiptProps> = ({
  companyName = "שם החברה",
  branchName = "שם הסניף",
  totalAmount = "₪00.00",
  items = [
    { name: "פריט", barcode: "ברקוד", quantity: 1, price: "₪00.00" },
    { name: "פריט", barcode: "ברקוד", quantity: 1, price: "₪00.00" },
    { name: "פריט", barcode: "ברקוד", quantity: 1, price: "₪00.00" },
  ],
}) => {
  return (
    <div
      className="rtl-container bg-white shadow-xl rounded-none w-full max-w-sm mx-auto"
      style={{
        maxWidth: "390px",
        boxShadow: "0 0 70px 0 rgba(106, 114, 139, 0.16)",
      }}
    >
      {/* Header with company logo placeholder */}
      <div className="flex justify-center items-center h-44 bg-receipt-lightgray border border-receipt-border">
        <div className="text-receipt-gray">
          <svg
            width="100"
            height="100"
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M84.375 15.625H15.625C13.9674 15.625 12.3777 16.2835 11.2056 17.4556C10.0335 18.6277 9.375 20.2174 9.375 21.875V78.125C9.375 79.7826 10.0335 81.3723 11.2056 82.5444C12.3777 83.7165 13.9674 84.375 15.625 84.375H84.375C86.0326 84.375 87.6223 83.7165 88.7944 82.5444C89.9665 81.3723 90.625 79.7826 90.625 78.125V21.875C90.625 20.2174 89.9665 18.6277 88.7944 17.4556C87.6223 16.2835 86.0326 15.625 84.375 15.625ZM84.375 21.875V62.0117L74.1914 51.832C73.611 51.2515 72.922 50.791 72.1636 50.4768C71.4052 50.1627 70.5924 50.0009 69.7715 50.0009C68.9506 50.0009 68.1378 50.1627 67.3794 50.4768C66.621 50.791 65.9319 51.2515 65.3516 51.832L57.5391 59.6445L40.3516 42.457C39.1796 41.2858 37.5905 40.6279 35.9336 40.6279C34.2767 40.6279 32.6876 41.2858 31.5156 42.457L15.625 58.3477V21.875H84.375ZM15.625 67.1875L35.9375 46.875L67.1875 78.125H15.625V67.1875ZM84.375 78.125H76.0273L61.9648 64.0625L69.7773 56.25L84.375 70.8516V78.125ZM56.25 39.0625C56.25 38.1354 56.5249 37.2291 57.04 36.4583C57.5551 35.6874 58.2871 35.0866 59.1437 34.7318C60.0002 34.377 60.9427 34.2842 61.852 34.4651C62.7613 34.6459 63.5965 35.0924 64.2521 35.7479C64.9076 36.4035 65.3541 37.2387 65.5349 38.148C65.7158 39.0573 65.623 39.9998 65.2682 40.8563C64.9134 41.7129 64.3126 42.4449 63.5417 42.96C62.7709 43.4751 61.8646 43.75 60.9375 43.75C59.6943 43.75 58.502 43.2561 57.6229 42.3771C56.7439 41.498 56.25 40.3057 56.25 39.0625Z"
              fill="#DADEE2"
            />
          </svg>
        </div>
      </div>

      {/* Company info section */}
      <div className="flex flex-col items-center gap-4 px-6 py-6">
        {/* Company logo small */}
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-receipt-lightgray border border-receipt-border rounded flex items-center justify-center">
            <svg
              width="40"
              height="40"
              viewBox="0 0 40 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M33.75 6.25H6.25C5.58696 6.25 4.95107 6.51339 4.48223 6.98223C4.01339 7.45107 3.75 8.08696 3.75 8.75V31.25C3.75 31.913 4.01339 32.5489 4.48223 33.0178C4.95107 33.4866 5.58696 33.75 6.25 33.75H33.75C34.413 33.75 35.0489 33.4866 35.5178 33.0178C35.9866 32.5489 36.25 31.913 36.25 31.25V8.75C36.25 8.08696 35.9866 7.45107 35.5178 6.98223C35.0489 6.51339 34.413 6.25 33.75 6.25ZM33.75 8.75V24.8047L29.6766 20.7328C29.4444 20.5006 29.1688 20.3164 28.8654 20.1907C28.5621 20.0651 28.2369 20.0004 27.9086 20.0004C27.5802 20.0004 27.2551 20.0651 26.9518 20.1907C26.6484 20.3164 26.3728 20.5006 26.1406 20.7328L23.0156 23.8578L16.1406 16.9828C15.6718 16.5143 15.0362 16.2512 14.3734 16.2512C13.7107 16.2512 13.075 16.5143 12.6062 16.9828L6.25 23.3391V8.75H33.75ZM6.25 26.875L14.375 18.75L26.875 31.25H6.25V26.875ZM33.75 31.25H30.4109L24.7859 25.625L27.9109 22.5L33.75 28.3406V31.25ZM22.5 15.625C22.5 15.2542 22.61 14.8916 22.816 14.5833C23.022 14.275 23.3149 14.0346 23.6575 13.8927C24.0001 13.7508 24.3771 13.7137 24.7408 13.786C25.1045 13.8584 25.4386 14.037 25.7008 14.2992C25.963 14.5614 26.1416 14.8955 26.214 15.2592C26.2863 15.6229 26.2492 15.9999 26.1073 16.3425C25.9654 16.6851 25.725 16.978 25.4167 17.184C25.1084 17.39 24.7458 17.5 24.375 17.5C23.8777 17.5 23.4008 17.3025 23.0492 16.9508C22.6975 16.5992 22.5 16.1223 22.5 15.625Z"
                fill="#D1D6DB"
              />
            </svg>
          </div>

          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold text-receipt-text">
              {companyName}
            </h1>
            <h2 className="text-lg text-receipt-text">{branchName}</h2>
          </div>
        </div>

        {/* Total amount */}
        <div className="text-2xl font-bold text-receipt-text text-center">
          {totalAmount}
        </div>

        {/* Items table header */}
        <div className="w-full">
          <div className="flex justify-between items-center mb-3">
            <span className="text-lg font-semibold text-receipt-text">
              פריט
            </span>
            <span className="text-lg font-semibold text-receipt-text">
              כמות
            </span>
            <span className="text-lg font-semibold text-receipt-text">
              סכום
            </span>
          </div>

          {/* Items list */}
          <div className="space-y-3">
            {items.map((item, index) => (
              <div key={index}>
                <div className="flex justify-between items-start">
                  <div className="text-right">
                    <div className="text-lg text-receipt-text">{item.name}</div>
                    <div className="text-base text-receipt-text opacity-80">
                      {item.barcode}
                    </div>
                  </div>
                  <span className="text-lg text-receipt-text">
                    {item.quantity}
                  </span>
                  <span className="text-lg text-receipt-text">
                    {item.price}
                  </span>
                </div>
              </div>
            ))}

            {/* Discount line */}
            <div className="flex justify-between items-center">
              <span className="text-lg text-receipt-orange">הנחת מבצע</span>
              <span className="text-lg text-receipt-orange">-₪00.00</span>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="w-full h-px bg-receipt-divider"></div>

        {/* Payment info */}
        <div className="w-full text-right space-y-1">
          <div className="text-lg font-semibold text-receipt-text">אשראי</div>
          <div className="text-lg text-receipt-text">
            תשלומים: 1 1234**** ₪00.00
          </div>
        </div>

        {/* Divider */}
        <div className="w-full h-px bg-receipt-divider"></div>

        {/* Summary section */}
        <div className="w-full space-y-3">
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">סכום ללא מע"מ</span>
            <span className="text-lg text-receipt-text">₪00.00</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">מע"מ</span>
            <span className="text-lg text-receipt-text">₪00.00</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">סכום לתשלום</span>
            <span className="text-lg text-receipt-text">₪00.00</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">מספר חשבונית</span>
            <span className="text-lg text-receipt-text">1005041234</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">תאריך ושעה</span>
            <span className="text-lg text-receipt-text">2024-11-23 20:03</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">מספר קופה</span>
            <span className="text-lg text-receipt-text">8</span>
          </div>
          <div className="flex justify-between">
            <span className="text-lg text-receipt-text">קופאי/ת</span>
            <span className="text-lg text-receipt-text">ישראל לוי</span>
          </div>
        </div>

        {/* Download button */}
        <button className="flex items-center justify-center gap-3 w-full px-4 py-3 border border-gray-200 rounded bg-white text-receipt-text hover:bg-gray-50 transition-colors">
          <svg
            width="18"
            height="18"
            viewBox="0 0 22 22"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M19.25 12.375V17.875C19.25 18.0573 19.1776 18.2322 19.0486 18.3611C18.9197 18.4901 18.7448 18.5625 18.5625 18.5625H3.4375C3.25516 18.5625 3.0803 18.4901 2.95136 18.3611C2.82243 18.2322 2.75 18.0573 2.75 17.875V12.375C2.75 12.1927 2.82243 12.0178 2.95136 11.8889C3.0803 11.7599 3.25516 11.6875 3.4375 11.6875C3.61984 11.6875 3.7947 11.7599 3.92364 11.8889C4.05257 12.0178 4.125 12.1927 4.125 12.375V17.1875H17.875V12.375C17.875 12.1927 17.9474 12.0178 18.0764 11.8889C18.2053 11.7599 18.3802 11.6875 18.5625 11.6875C18.7448 11.6875 18.9197 11.7599 19.0486 11.8889C19.1776 12.0178 19.25 12.1927 19.25 12.375ZM10.5136 12.8614C10.5774 12.9253 10.6533 12.976 10.7367 13.0106C10.8202 13.0452 10.9097 13.063 11 13.063C11.0903 13.063 11.1798 13.0452 11.2633 13.0106C11.3467 12.976 11.4226 12.9253 11.4864 12.8614L14.9239 9.42391C14.9878 9.36003 15.0385 9.2842 15.073 9.20074C15.1076 9.11728 15.1254 9.02783 15.1254 8.9375C15.1254 8.84717 15.1076 8.75772 15.073 8.67426C15.0385 8.5908 14.9878 8.51497 14.9239 8.45109C14.86 8.38722 14.7842 8.33655 14.7007 8.30198C14.6173 8.26741 14.5278 8.24962 14.4375 8.24962C14.3472 8.24962 14.2577 8.26741 14.1743 8.30198C14.0908 8.33655 14.015 8.38722 13.9511 8.45109L11.6875 10.7155V2.75C11.6875 2.56766 11.6151 2.3928 11.4861 2.26386C11.3572 2.13493 11.1823 2.0625 11 2.0625C10.8177 2.0625 10.6428 2.13493 10.5139 2.26386C10.3849 2.3928 10.3125 2.56766 10.3125 2.75V10.7155L8.04891 8.45109C7.9199 8.32209 7.74494 8.24962 7.5625 8.24962C7.38006 8.24962 7.2051 8.32209 7.07609 8.45109C6.94709 8.5801 6.87462 8.75506 6.87462 8.9375C6.87462 9.11994 6.94709 9.2949 7.07609 9.42391L10.5136 12.8614Z"
              fill="#1B2534"
            />
          </svg>
          <span className="text-base font-medium text-receipt-text">
            הורדת מסמך מקור
          </span>
        </button>

        {/* Footer text */}
        <p className="text-base text-receipt-text text-center leading-6 px-6">
          לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג עלית, סד דו אייסמוד
          טמפור אינצידידונט אוט לבורה ודולור מגנה
        </p>

        {/* Divider */}
        <div className="w-full h-px bg-receipt-divider"></div>

        {/* Barcode section */}
        <div className="flex flex-col items-center space-y-2">
          <div className="w-96 h-28 relative">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/279d186c0541b7ca20f1ef1b56f518a9b724afac?width=743"
              alt="Barcode"
              className="w-full h-24 object-contain"
            />
            <div className="text-lg text-receipt-text text-center tracking-widest mt-2">
              20240101005041234
            </div>
          </div>
        </div>

        {/* Bottom logo placeholder */}
        <div className="flex justify-center items-center h-44 bg-receipt-lightgray border border-receipt-border w-full">
          <div className="text-receipt-gray">
            <svg
              width="100"
              height="100"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M84.375 15.625H15.625C13.9674 15.625 12.3777 16.2835 11.2056 17.4556C10.0335 18.6277 9.375 20.2174 9.375 21.875V78.125C9.375 79.7826 10.0335 81.3723 11.2056 82.5444C12.3777 83.7165 13.9674 84.375 15.625 84.375H84.375C86.0326 84.375 87.6223 83.7165 88.7944 82.5444C89.9665 81.3723 90.625 79.7826 90.625 78.125V21.875C90.625 20.2174 89.9665 18.6277 88.7944 17.4556C87.6223 16.2835 86.0326 15.625 84.375 15.625ZM84.375 21.875V62.0117L74.1914 51.832C73.611 51.2515 72.922 50.791 72.1636 50.4768C71.4052 50.1627 70.5924 50.0009 69.7715 50.0009C68.9506 50.0009 68.1378 50.1627 67.3794 50.4768C66.621 50.791 65.9319 51.2515 65.3516 51.832L57.5391 59.6445L40.3516 42.457C39.1796 41.2858 37.5905 40.6279 35.9336 40.6279C34.2767 40.6279 32.6876 41.2858 31.5156 42.457L15.625 58.3477V21.875H84.375ZM15.625 67.1875L35.9375 46.875L67.1875 78.125H15.625V67.1875ZM84.375 78.125H76.0273L61.9648 64.0625L69.7773 56.25L84.375 70.8516V78.125ZM56.25 39.0625C56.25 38.1354 56.5249 37.2291 57.04 36.4583C57.5551 35.6874 58.2871 35.0866 59.1437 34.7318C60.0002 34.377 60.9427 34.2842 61.852 34.4651C62.7613 34.6459 63.5965 35.0924 64.2521 35.7479C64.9076 36.4035 65.3541 37.2387 65.5349 38.148C65.7158 39.0573 65.623 39.9998 65.2682 40.8563C64.9134 41.7129 64.3126 42.4449 63.5417 42.96C62.7709 43.4751 61.8646 43.75 60.9375 43.75C59.6943 43.75 58.502 43.2561 57.6229 42.3771C56.7439 41.498 56.25 40.3057 56.25 39.0625Z"
                fill="#DADEE2"
              />
            </svg>
          </div>
        </div>

        {/* Powered by footer */}
        <div className="flex items-center justify-center gap-2 text-receipt-gray">
          <span className="text-base">Powered By</span>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/91e1ad88de1b6e9d25f01f451950bf2e2ea96817?width=134"
            alt="Comax Logo"
            className="h-3"
          />
        </div>
      </div>
    </div>
  );
};

export default InvoiceReceipt;
