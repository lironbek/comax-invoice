import React from "react";
import InvoiceReceipt from "../components/InvoiceReceipt";
import EditingSidebar from "../components/EditingSidebar";

const InvoiceInterface: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#FAFBFC]">
      {/* Top green header bar */}
      <div className="bg-receipt-green h-20 flex items-center justify-between px-12">
        {/* Left side - user info */}
        <div className="flex items-center gap-3 text-white">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <g clipPath="url(#clip0_111_905)">
              <path
                d="M9.00017 0.299805C4.19777 0.299805 0.300171 4.1974 0.300171 8.9998C0.300171 13.8022 4.19777 17.6998 9.00017 17.6998C13.8026 17.6998 17.7002 13.8022 17.7002 8.9998C17.7002 4.1974 13.8026 0.299805 9.00017 0.299805ZM9.00017 2.9098C10.4444 2.9098 11.6102 4.0756 11.6102 5.5198C11.6102 6.964 10.4444 8.1298 9.00017 8.1298C7.55597 8.1298 6.39017 6.964 6.39017 5.5198C6.39017 4.0756 7.55597 2.9098 9.00017 2.9098ZM9.00017 15.2638C6.82517 15.2638 4.90247 14.1502 3.78017 12.4624C3.80627 10.7311 7.26017 9.7828 9.00017 9.7828C10.7315 9.7828 14.1941 10.7311 14.2202 12.4624C13.0979 14.1502 11.1752 15.2638 9.00017 15.2638Z"
                fill="white"
              />
            </g>
          </svg>
          <span className="text-base font-semibold">שם משתמש</span>
        </div>

        {/* Right side - company info */}
        <div className="flex items-center gap-3 text-white">
          <span className="text-base font-semibold">שם חברה</span>
          <div className="w-9 h-9 bg-white rounded"></div>
        </div>
      </div>

      {/* Main content area */}
      <div className="flex min-h-[calc(100vh-80px)]">
        {/* Left side - Invoice receipt */}
        <div className="flex-1 flex justify-center items-start py-16 px-4">
          <InvoiceReceipt />
        </div>

        {/* Right side - Editing sidebar */}
        <div className="hidden lg:block">
          <EditingSidebar />
        </div>
      </div>
    </div>
  );
};

export default InvoiceInterface;
