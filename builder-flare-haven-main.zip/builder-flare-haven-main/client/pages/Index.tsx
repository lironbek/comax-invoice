import InvoiceInterface from "./InvoiceInterface";

export default function Index() {
  return <InvoiceInterface />;
}
